DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `voicetech`.`recount_analytics`(
    IN `fromDateV` VARCHAR(20),
    IN `toDateV` VARCHAR(20),
    IN `tag_idV` VARCHAR(20),
    IN `dataset_idV` VARCHAR(20),
    IN `interactionIDV` VARCHAR(40))
    NO SQL
BEGIN

  DECLARE counterV INT DEFAULT 0;
  DECLARE wordsV TEXT DEFAULT '';
  DECLARE wordV TEXT DEFAULT '';
  DECLARE word_idsV TEXT DEFAULT '';
  DECLARE word_idV VARCHAR(20) DEFAULT '';
  DECLARE n INT DEFAULT 0;
  DECLARE current_tag_idV INT DEFAULT NULL;
  DECLARE current_tag_class_idV VARCHAR(20) DEFAULT '';
  DECLARE matchSrcV LONGTEXT DEFAULT '';
  DECLARE matchCustomerChatV LONGTEXT DEFAULT '';
  DECLARE matchDstV LONGTEXT DEFAULT '';
  DECLARE matchAgentChatV LONGTEXT DEFAULT '';

END
;;
